<?php
// Include file koneksi database
include 'conf/conf.php';

// Ambil nilai filter dari permintaan POST
$tahunAngkatan = $_POST['tahunAngkatan'];
$fakultas = $_POST['fakultas'];
$prodi = $_POST['prodi'];

// Bangun query berdasarkan filter yang diberikan
$sql = "SELECT * FROM mahasiswa WHERE 1=1";
if (!empty($tahunAngkatan)) {
    $sql .= " AND mhsAngkatan = '$tahunAngkatan'";
}
if (!empty($fakultas)) {
    $sql .= " AND FAKULTAS = '$fakultas'";
}
if (!empty($prodi)) {
    $sql .= " AND PRODI = '$prodi'";
}

// Eksekusi query
$result = $conn->query($sql);

// Cek jika ada data yang ditemukan
if ($result->num_rows > 0) {
    // Loop melalui data dan tampilkan dalam tabel
    while ($row = $result->fetch_assoc()) {
        echo '<tr>';
        echo '<td>' . htmlspecialchars($row['mhsNiu']) . '</td>';
        echo '<td>' . htmlspecialchars($row['mhsAngkatan']) . '</td>';
        echo '<td>' . htmlspecialchars($row['mhsNama']) . '</td>';
        echo '<td>' . htmlspecialchars($row['mhsSemesterMasuk']) . '</td>';
        echo '<td>' . htmlspecialchars($row['PRODI']) . '</td>';
        echo '<td>' . htmlspecialchars($row['FAKULTAS']) . '</td>';
        echo '<td>' . htmlspecialchars($row['mhsStatusMasukPt']) . '</td>';
        echo '<td>' . htmlspecialchars($row['mhsJlrrKode']) . '</td>';
        echo '</tr>';
    }
} else {
    echo '<tr><td colspan="8">No data found</td></tr>';
}

// Tutup koneksi database
$conn->close();
