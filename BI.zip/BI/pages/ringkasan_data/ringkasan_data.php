<?php
include './conf/conf.php';

// Ambil data mahasiswa
$sql = "SELECT * FROM mahasiswa";
$result = $conn->query($sql);

$mahasiswaData = [];
$prodiOptions = [];
$kodeOptions = [];

if ($result->num_rows > 0) {
    // Mengambil data dari tabel
    while ($row = $result->fetch_assoc()) {
        $mahasiswaData[] = $row;
        $prodiOptions[] = $row['PRODI'];
        $kodeOptions[] = $row['mhsJlrrKode'];
    }
}

// Menghapus duplikat pilihan
$prodiOptions = array_unique($prodiOptions);
$kodeOptions = array_unique($kodeOptions);

$conn->close();
?>

<!-- Tempat untuk Grafik -->
<div class="container-xxl flex-grow-1 container-p-y">
    <div class="row">
        <div class="col-12 col-lg-12 order-2 order-md-3 order-lg-2 mb-4">
            <div class="card">
                <div class="row row-bordered g-0">
                    <div class="col-md-6">
                        <!-- Konten Kiri -->
                        <div class="p-3">
                            <label for="prodiSelect">Pilih PRODI:</label>
                            <select id="prodiSelect" class="form-select">
                                <option value="">--Pilih PRODI--</option>
                                <?php foreach ($prodiOptions as $prodi) : ?>
                                <option value="<?= $prodi ?>"><?= $prodi ?></option>
                                <?php endforeach; ?>
                            </select>

                            <label for="kodeSelect" class="mt-3">Pilih Kode Jurusan:</label>
                            <select id="kodeSelect" class="form-select">
                                <option value="">--Pilih Kode Jurusan--</option>
                                <?php foreach ($kodeOptions as $kode) : ?>
                                <option value="<?= $kode ?>"><?= $kode ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <!-- Konten Tengah -->
                        <div class="p-3">
                            <div class="total-info">
                                <div class="row ">
                                    <div class="col">
                                        <p>Total berdasarkan PRODI</p>
                                    </div>
                                    <div class="col-auto">
                                        <span class="total-colon">:</span>
                                    </div>
                                    <div class="col-md-2">
                                        <span id="totalProdi" class="total-span">0</span>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col">
                                        <p>Total JALUR REG berdasarkan PRODI</p>
                                    </div>
                                    <div class="col-auto">
                                        <span class="total-colon">:</span>
                                    </div>
                                    <div class="col-md-2">
                                        <span id="totalRegProdi" class="total-span">0</span>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col">
                                        <p>Total Kode Jurusan</p>
                                    </div>
                                    <div class="col-auto">
                                        <span class="total-colon">:</span>
                                    </div>
                                    <div class="col-md-2">
                                        <span id="totalKode" class="total-span">0</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>


                    <div class="col-md-12">
                        <!-- Konten Kanan -->
                        <div class="p-3 text-center">
                            <div id="chartContainer">Belum ada Prodi yang dipilih</div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<style>

</style>


<script>
// Data mahasiswa dalam format JavaScript
const mahasiswaData = <?php echo json_encode($mahasiswaData); ?>;

// Event listener untuk select elements
document.getElementById('prodiSelect').addEventListener('change', updateTotals);
document.getElementById('kodeSelect').addEventListener('change', updateTotals);

function updateTotals() {
    const selectedProdi = document.getElementById('prodiSelect').value;
    const selectedKode = document.getElementById('kodeSelect').value;

    let totalProdi = 0;
    let totalRegProdi = 0;
    let totalKode = 0;

    mahasiswaData.forEach(mahasiswa => {
        if (mahasiswa.PRODI === selectedProdi) {
            totalProdi++;
            if (mahasiswa.mhsJlrrKode === 'REG') {
                totalRegProdi++;
            }
        }
        if (mahasiswa.mhsJlrrKode === selectedKode) {
            totalKode++;
        }
    });

    document.getElementById('totalProdi').innerText = totalProdi;
    document.getElementById('totalRegProdi').innerText = totalRegProdi;
    document.getElementById('totalKode').innerText = totalKode;

    // Update chart
    if (selectedProdi === "" && selectedKode === "") {
        document.getElementById('chartContainer').innerHTML = "Belum ada PRODI yang dipilih";
    } else {
        updateChart(totalProdi, totalRegProdi, totalKode);
    }
}

function updateChart(totalProdi, totalRegProdi, totalKode) {
    Highcharts.chart('chartContainer', {
        chart: {
            type: 'line'
        },
        title: {
            text: 'Jumlah Total Mahasiswa'
        },
        xAxis: {
            categories: ['Total Prodi', 'Jalur REG', 'Total Kode Jurusan']
        },
        yAxis: {
            title: {
                text: 'Jumlah'
            }
        },
        series: [{
            name: 'Jumlah',
            data: [totalProdi, totalRegProdi, totalKode]
        }]
    });
}

// Inisialisasi chart dengan data awal
document.getElementById('chartContainer').innerHTML = "Belum ada PRODI yang dipilih";
</script>