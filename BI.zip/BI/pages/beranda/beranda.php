<div class="container-xxl flex-grow-1 container-p-y">
    <div class="row">
        <div class="col-lg-12 mb-4 order-0">
            <div class="card">
                <div class="d-flex align-items-end row">
                    <div class="col-sm-7">
                        <div class="card-body">
                            <h5 class="card-title text-primary">Welcome, <?php echo $_SESSION['username']; ?></h5>
                            <p class="mb-4">
                                Selamat Datang di Sistem <span class="fw-bold">Upatik Unima.</span> Sistem ini adalah
                                sistem
                                yang dirancang untuk memfasilitasi dan mengoptimalkan proses analisis data. Dengan
                                memanfaatkan
                                teknologi Business Intelligence (BI), sistem ini membantu pengguna dalam pengambilan
                                keputusan
                                strategis melalui visualisasi data yang informatif dan mudah dipahami. Diharapkan sistem
                                ini dapat
                                memberikan wawasan yang mendalam dan akurat untuk mendukung berbagai kebutuhan bisnis
                                dan akademik.
                            </p>


                            <a href="#datadata" class="btn btn-sm btn-outline-primary"> Lihat Data Visualisasi Yuk</a>
                        </div>
                    </div>
                    <div class="col-sm-5 text-center text-sm-left">
                        <div class="card-body pb-0 px-0 px-md-4">
                            <img src="assets/img/illustrations/man-with-laptop-light.png" height="250"
                                alt="View Badge User" data-app-dark-img="illustrations/man-with-laptop-dark.png"
                                data-app-light-img="illustrations/man-with-laptop-light.png" />
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-lg-12 ">
            <div class="row">
                <div class="col-lg-6 col-md-12 col-6 mb-4">
                    <div class="card">
                        <div class="d-flex align-items-end row">
                            <div class="col-sm-7">
                                <div class="card-body">
                                    <div class="card-title d-flex align-items-start justify-content-between">
                                        <div class="avatar flex-shrink-0">
                                            <img src="assets/img/icons/unicons/chart-success.png" alt="chart success"
                                                class="rounded" />
                                        </div>

                                    </div>
                                    <?php
                                    // Include file koneksi database jika diperlukan
                                    include './conf/conf.php';

                                    // Query untuk mengambil total mahasiswa dari database
                                    $sql = "SELECT COUNT(*) as total_mahasiswa FROM mahasiswa";
                                    $result = $conn->query($sql);

                                    // Inisialisasi variabel total mahasiswa
                                    $total_mahasiswa = 0;

                                    // Cek jika query berhasil dieksekusi
                                    if ($result && $result->num_rows > 0) {
                                        // Ambil data total mahasiswa
                                        $row = $result->fetch_assoc();
                                        $total_mahasiswa = $row['total_mahasiswa'];
                                    }

                                    // Tutup koneksi database
                                    $conn->close();
                                    ?>

                                    <span class="fw-semibold d-block mb-1">Total Mahasiswa</span>
                                    <h3 class="card-title mb-2"><?php echo $total_mahasiswa; ?></h3>

                                </div>

                            </div>
                            <div class="col-sm-4 text-center text-sm-left">
                                <div class="card-body pb-0 px-0">
                                    <img src="assets/img/illustrations/002.png" height="140" alt="View Badge User"
                                        data-app-dark-img="illustrations/man-with-laptop-dark.png"
                                        data-app-light-img="illustrations/man-with-laptop-light.png" />
                                </div>
                            </div>

                        </div>

                    </div>
                </div>

                <div class="col-lg-6 col-md-12 col-6 mb-4">
                    <div class="card">
                        <div class="d-flex align-items-end row">
                            <div class="col-sm-7">
                                <div class="card-body">
                                    <div class="card-title d-flex align-items-start justify-content-between">
                                        <div class="avatar flex-shrink-0">
                                            <img src="assets/img/icons/unicons/cc-warning.png" alt="chart success"
                                                class="rounded" />
                                        </div>
                                    </div>
                                    <?php
                                    // Include file koneksi database jika diperlukan
                                    include './conf/conf.php';

                                    // Query untuk mengambil total mahasiswa dari database
                                    $sql = "SELECT COUNT(*) as jumlah1 FROM mahasiswa WHERE PRODI = 'S1 Manajemen'";
                                    $result = $conn->query($sql);

                                    // Inisialisasi variabel total mahasiswa
                                    $jumlah1 = 0;

                                    // Cek jika query berhasil dieksekusi
                                    if ($result && $result->num_rows > 0) {
                                        // Ambil data total mahasiswa
                                        $row = $result->fetch_assoc();
                                        $jumlah1 = $row['jumlah1'];
                                    } else {
                                        echo "Error: " . $conn->error;
                                    }

                                    // Tutup koneksi database
                                    $conn->close();
                                    ?>

                                    <span class="fw-semibold d-block mb-1">Total Jurusan S1 Manajemen</span>
                                    <h3 class="card-title mb-2"><?php echo $jumlah1; ?></h3>


                                </div>
                            </div>
                            <div class="col-sm-4 text-center text-sm-left">
                                <div class="card-body pb-0 px-0 px-md-4">
                                    <img src="assets/img/illustrations/003.png" height="140" alt="View Badge User"
                                        data-app-dark-img="illustrations/man-with-laptop-dark.png"
                                        data-app-light-img="illustrations/man-with-laptop-light.png" />
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-lg-6 col-md-12 col-6 mb-4">
                    <div class="card">
                        <div class="d-flex align-items-end row">
                            <div class="col-sm-7">
                                <div class="card-body">
                                    <div class="card-title d-flex align-items-start justify-content-between">
                                        <div class="avatar flex-shrink-0">
                                            <img src="assets/img/icons/unicons/cc-primary.png" alt="chart success"
                                                class="rounded" />
                                        </div>
                                    </div>
                                    <?php
                                    // Include file koneksi database jika diperlukan
                                    include './conf/conf.php';

                                    // Query untuk mengambil total mahasiswa dari database
                                    $sql = "SELECT COUNT(*) as jumlah2 FROM mahasiswa WHERE PRODI = 'D3 Teknik Sipil'";
                                    $result = $conn->query($sql);

                                    // Inisialisasi variabel total mahasiswa
                                    $jumlah2 = 0;

                                    // Cek jika query berhasil dieksekusi
                                    if ($result && $result->num_rows > 0) {
                                        // Ambil data total mahasiswa
                                        $row = $result->fetch_assoc();
                                        $jumlah2 = $row['jumlah2'];
                                    } else {
                                        echo "Error: " . $conn->error;
                                    }

                                    // Tutup koneksi database
                                    $conn->close();
                                    ?>

                                    <span class="fw-semibold d-block mb-1">Total Jurusan D3 Teknik Sipil</span>
                                    <h3 class="card-title mb-2"><?php echo $jumlah2; ?></h3>

                                </div>
                            </div>
                            <div class="col-sm-4 text-center text-sm-left">
                                <div class="card-body pb-0 px-0 px-md-4">
                                    <img src="assets/img/illustrations/004.png" height="140" alt="View Badge User"
                                        data-app-dark-img="illustrations/man-with-laptop-dark.png"
                                        data-app-light-img="illustrations/man-with-laptop-light.png" />
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-lg-6 col-md-12 col-6 mb-4">
                    <div class="card">
                        <div class="d-flex align-items-end row">
                            <div class="col-sm-7">
                                <div class="card-body">
                                    <div class="card-title d-flex align-items-start justify-content-between">
                                        <div class="avatar flex-shrink-0">
                                            <img src="assets/img/icons/unicons/chart.png" alt="chart success"
                                                class="rounded" />
                                        </div>
                                    </div>
                                    <?php
                                    // Include file koneksi database jika diperlukan
                                    include './conf/conf.php';

                                    // Query untuk mengambil total mahasiswa dari database
                                    $sql = "SELECT COUNT(*) as jumlah3 FROM mahasiswa WHERE PRODI = 'S1 Psikologi'";
                                    $result = $conn->query($sql);

                                    // Inisialisasi variabel total mahasiswa
                                    $jumlah3 = 0;

                                    // Cek jika query berhasil dieksekusi
                                    if ($result && $result->num_rows > 0) {
                                        // Ambil data total mahasiswa
                                        $row = $result->fetch_assoc();
                                        $jumlah3 = $row['jumlah3'];
                                    } else {
                                        echo "Error: " . $conn->error;
                                    }

                                    // Tutup koneksi database
                                    $conn->close();
                                    ?>

                                    <span class="fw-semibold d-block mb-1">Total Jurusan S1 Psikologi</span>
                                    <h3 class="card-title mb-2"><?php echo $jumlah3; ?></h3>
                                </div>
                            </div>
                            <div class="col-sm-4 text-center text-sm-left">
                                <div class="card-body pb-0 px-0 px-md-4">
                                    <img src="assets/img/illustrations/006.png" height="140" alt="View Badge User"
                                        data-app-dark-img="illustrations/man-with-laptop-dark.png"
                                        data-app-light-img="illustrations/man-with-laptop-light.png" />
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <a href="?q=ringkasan_data" class="btn btn-md mb-5 text-info"><i class="fa-solid fa-arrow-right"></i> More
            Data</a>


        <div id="datadata" class="col-12 col-lg-12 order-2 order-md-3 order-lg-2 mb-4">
            <div class="card">
                <div class="row row-bordered g-0">
                    <div class="col-md-12">
                        <h5 class="card-header m-0 me-2 pb-3">Total Mahasiswa</h5>
                        <div id="chart_div"></div>
                    </div>
                </div>
            </div>
        </div>
        <div id="datachartpie2" class="col-12 col-lg-12 order-2 order-md-3 order-lg-2 mb-4">
            <div class="card">
                <div class="row row-bordered g-0">
                    <div class="col-md-12 p-1">
                        <div class="col-md-4 p-2">
                            <label for="prodiFilter" class="mb-2">Filter :</label>
                            <select id="prodiFilter" class="form-select">
                                <option value="all">Semua Jurusan</option>
                            </select>
                        </div>
                        <h5 class="card-header m-0 me-2 pb-3">Total Mahasiswa</h5>
                        <div id="chart_div_pie"></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>