<div class="container-xxl flex-grow-1 container-p-y">
    <div class="row">
        <div class="col-12 col-lg-12 order-2 order-md-3 order-lg-2 mb-4">
            <div class="card">
                <div class="row row-bordered g-0">
                    <div class="col-md-12">
                        <div class="row">
                            <div class="col-md-9">
                                <div class="mb-3">
                                    <h5 class="card-header m-0 me-2 pb-3">Data Business Intelligence</h5>
                                </div>
                            </div>
                            <div class="col-md-3 mt-3">
                                <div class="d-flex">
                                    <button type="button" class="btn btn-primary m-0 me-2" data-bs-toggle="modal"
                                        data-bs-target="#importModal">Import Data</button>
                                    <button type="button" class="btn btn-danger" data-bs-toggle="modal"
                                        data-bs-target="#deleteModal">Delete All</button>
                                </div>
                            </div>
                        </div>
                        <?php
                        // Include file koneksi database
                        include './conf/conf.php';

                        // Query untuk mengambil opsi filter
                        $sqlTahunAngkatan = "SELECT DISTINCT mhsAngkatan FROM mahasiswa ORDER BY mhsAngkatan DESC";
                        $sqlFakultas = "SELECT DISTINCT FAKULTAS FROM mahasiswa";
                        $sqlProdi = "SELECT DISTINCT PRODI FROM mahasiswa";

                        // Eksekusi query
                        $resultTahunAngkatan = $conn->query($sqlTahunAngkatan);
                        $resultFakultas = $conn->query($sqlFakultas);
                        $resultProdi = $conn->query($sqlProdi);
                        ?>

                        <div class="row mb-2 p-4">
                            <div class="col-md-4">
                                <select id="tahunAngkatanFilter" class="form-select">
                                    <option value="">Filter Tahun Angkatan</option>
                                    <?php
                                    // Tambahkan opsi filter Tahun Angkatan
                                    if ($resultTahunAngkatan->num_rows > 0) {
                                        while ($row = $resultTahunAngkatan->fetch_assoc()) {
                                            echo '<option value="' . htmlspecialchars($row['mhsAngkatan']) . '">' . htmlspecialchars($row['mhsAngkatan']) . '</option>';
                                        }
                                    }
                                    ?>
                                </select>
                            </div>
                            <div class="col-md-4">
                                <select id="fakultasFilter" class="form-select">
                                    <option value="">Filter Fakultas</option>
                                    <?php
                                    // Tambahkan opsi filter Fakultas
                                    if ($resultFakultas->num_rows > 0) {
                                        while ($row = $resultFakultas->fetch_assoc()) {
                                            echo '<option value="' . htmlspecialchars($row['FAKULTAS']) . '">' . htmlspecialchars($row['FAKULTAS']) . '</option>';
                                        }
                                    }
                                    ?>
                                </select>
                            </div>
                            <div class="col-md-4">
                                <select id="prodiFilter" class="form-select">
                                    <option value="">Filter Program Studi</option>
                                    <?php
                                    // Tambahkan opsi filter Program Studi
                                    if ($resultProdi->num_rows > 0) {
                                        while ($row = $resultProdi->fetch_assoc()) {
                                            echo '<option value="' . htmlspecialchars($row['PRODI']) . '">' . htmlspecialchars($row['PRODI']) . '</option>';
                                        }
                                    }
                                    ?>
                                </select>
                            </div>
                        </div>

                        <div class="table-responsive p-2">
                            <table id="dataTable" class="table table-striped text-center">
                                <thead>
                                    <tr>
                                        <th>NIM</th>
                                        <th>Tahun Angkatan</th>
                                        <th>Nama</th>
                                        <th>Semester Masuk</th>
                                        <th>Program Studi</th>
                                        <th>Fakultas</th>
                                        <th>Status Masuk</th>
                                        <th>Jalur Masuk</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                    // Include file koneksi database
                                    include './conf/conf.php';

                                    // Query untuk mengambil data dari tabel mahasiswa
                                    $sql = "SELECT * FROM mahasiswa";
                                    $result = $conn->query($sql);

                                    // Cek jika ada data yang ditemukan
                                    if ($result->num_rows > 0) :
                                        // Loop melalui data dan tampilkan dalam tabel
                                        while ($row = $result->fetch_assoc()) :
                                    ?>
                                    <tr>
                                        <td><?= htmlspecialchars($row['mhsNiu']); ?></td>
                                        <td><?= htmlspecialchars($row['mhsAngkatan']); ?></td>
                                        <td><?= htmlspecialchars($row['mhsNama']); ?></td>
                                        <td><?= htmlspecialchars($row['mhsSemesterMasuk']); ?></td>
                                        <td><?= htmlspecialchars($row['PRODI']); ?></td>
                                        <td><?= htmlspecialchars($row['FAKULTAS']); ?></td>
                                        <td><?= htmlspecialchars($row['mhsStatusMasukPt']); ?></td>
                                        <td><?= htmlspecialchars($row['mhsJlrrKode']); ?></td>
                                    </tr>
                                    <?php
                                        endwhile;
                                    else :
                                        ?>
                                    <tr>
                                        <td colspan="8">No data found</td>
                                    </tr>
                                    <?php
                                    endif;

                                    // Tutup koneksi database
                                    $conn->close();
                                    ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>



        <?php
        // Include file koneksi database
        include './conf/conf.php';

        // Query untuk menghitung jumlah mahasiswa per tahun angkatan
        $sqlCountTahunAngkatan = "SELECT mhsAngkatan, COUNT(*) AS jumlah FROM mahasiswa GROUP BY mhsAngkatan ORDER BY mhsAngkatan DESC";
        $resultCountTahunAngkatan = $conn->query($sqlCountTahunAngkatan);

        // Query untuk menghitung jumlah mahasiswa per fakultas
        $sqlCountFakultas = "SELECT FAKULTAS, COUNT(*) AS jumlah FROM mahasiswa GROUP BY FAKULTAS";
        $resultCountFakultas = $conn->query($sqlCountFakultas);

        // Query untuk menghitung jumlah mahasiswa per program studi
        $sqlCountProdi = "SELECT PRODI, COUNT(*) AS jumlah FROM mahasiswa GROUP BY PRODI";
        $resultCountProdi = $conn->query($sqlCountProdi);
        ?>


        <!-- Bagian KPI dalam bentuk tabel -->
        <div class="col-12 col-lg-12 order-2 order-md-3 order-lg-2 mb-4">
            <div class="card">
                <div class="row mt-4 p-4">
                    <div class="col-md-12 mb-5">
                        <h5 class="text-center">Jumlah Mahasiswa per Tahun Angkatan</h5>
                        <div class="table-responsive">
                            <table id="pertama" class="table table-bordered text-center">
                                <thead>
                                    <tr>
                                        <th>Tahun Angkatan</th>
                                        <th>Jumlah Mahasiswa</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                    if ($resultCountTahunAngkatan->num_rows > 0) {
                                        while ($row = $resultCountTahunAngkatan->fetch_assoc()) {
                                            echo '<tr>';
                                            echo '<td>' . htmlspecialchars($row['mhsAngkatan']) . '</td>';
                                            echo '<td>' . htmlspecialchars($row['jumlah']) . '</td>';
                                            echo '</tr>';
                                        }
                                    }
                                    ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                    <div class="col-md-12 mb-5">
                        <h5 class="text-center">Jumlah Mahasiswa per Fakultas</h5>
                        <div class="table-responsive">
                            <table id="kedua" class="table table-bordered text-center">
                                <thead>
                                    <tr>
                                        <th>Fakultas</th>
                                        <th>Jumlah Mahasiswa</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                    if ($resultCountFakultas->num_rows > 0) {
                                        while ($row = $resultCountFakultas->fetch_assoc()) {
                                            echo '<tr>';
                                            echo '<td>' . htmlspecialchars($row['FAKULTAS']) . '</td>';
                                            echo '<td>' . htmlspecialchars($row['jumlah']) . '</td>';
                                            echo '</tr>';
                                        }
                                    }
                                    ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                    <div class="col-md-12">
                        <h5 class="text-center">Jumlah Mahasiswa per Program Studi</h5>
                        <div class="table-responsive">
                            <table id="ketiga" class="table table-bordered text-center">
                                <thead>
                                    <tr>
                                        <th>Program Studi</th>
                                        <th>Jumlah Mahasiswa</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                    if ($resultCountProdi->num_rows > 0) {
                                        while ($row = $resultCountProdi->fetch_assoc()) {
                                            echo '<tr>';
                                            echo '<td>' . htmlspecialchars($row['PRODI']) . '</td>';
                                            echo '<td>' . htmlspecialchars($row['jumlah']) . '</td>';
                                            echo '</tr>';
                                        }
                                    }
                                    ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Akhir Bagian KPI dalam bentuk tabel -->
    </div>
</div>

<!-- Modal untuk Import Data -->
<div class="modal fade" id="importModal" tabindex="-1" role="dialog" aria-labelledby="importModalLabel"
    aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <form action="?q=import_data" method="post" enctype="multipart/form-data">
                <div class="modal-header">
                    <h5 class="modal-title" id="importModalLabel">Import Data Excel</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close">

                    </button>
                </div>
                <div class="modal-body">
                    <div class="form-group">
                        <label for="file">Pilih file Excel:</label>
                        <input type="file" class="form-control" id="file" name="file" required>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Tutup</button>
                    <button type="submit" class="btn btn-primary">Import Data</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Modal untuk Delete Data -->
<div class="modal fade" id="deleteModal" tabindex="-1" role="dialog" aria-labelledby="deleteModalLabel"
    aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <form action="?q=d_all" method="post">
                <div class="modal-header">
                    <h5 class="modal-title" id="deleteModalLabel">Delete Data</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <p>Are you sure you want to delete the selected data?</p>
                    <input type="hidden" name="dataId" id="dataId">
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-danger">Delete</button>
                </div>
            </form>
        </div>
    </div>
</div>