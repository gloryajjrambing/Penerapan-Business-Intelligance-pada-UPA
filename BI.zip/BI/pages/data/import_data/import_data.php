<?php

// Include file koneksi database jika diperlukan
include './conf/conf.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_FILES['file'])) {
    // Validasi file
    $file = $_FILES['file']['tmp_name'];
    $fileType = pathinfo($_FILES['file']['name'], PATHINFO_EXTENSION);
    if ($fileType !== 'csv') {
        echo 'Error: Only CSV files are allowed.';
        exit();
    }

    // Baca file CSV
    $handle = fopen($file, "r");
    if ($handle !== FALSE) {
        // Loop melalui setiap baris di file CSV
        while (($data = fgetcsv($handle, 1000, ",")) !== FALSE) {
            // Ambil data dari setiap kolom
            $mhsNiu = $data[0];
            $mhsAngkatan = $data[1];
            $mhsNama = $data[2];
            $mhsSemesterMasuk = $data[3];
            $PRODI = $data[4];
            $FAKULTAS = $data[5];
            $mhsStatusMasukPt = $data[6];
            $mhsJlrrKode = $data[7];

            // Query untuk memasukkan data ke tabel mahasiswa dengan parameter prepared statement
            $sql = "INSERT INTO mahasiswa (mhsNiu, mhsAngkatan, mhsNama, mhsSemesterMasuk, PRODI, FAKULTAS, mhsStatusMasukPt, mhsJlrrKode)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("ssssssss", $mhsNiu, $mhsAngkatan, $mhsNama, $mhsSemesterMasuk, $PRODI, $FAKULTAS, $mhsStatusMasukPt, $mhsJlrrKode);

            // Eksekusi query
            if (!$stmt->execute()) {
                echo "Error: " . $sql . "<br>" . $stmt->error;
            }
            $stmt->close();
        }
        fclose($handle);

        // Tutup koneksi database
        $conn->close();

        // Redirect kembali ke halaman utama setelah import selesai
        // Mengarahkan kembali ke halaman utama dengan JavaScript
        echo '<script>
             alert("Data successfully imported!");
             window.location.href = "?q=data";
           </script>';
        exit();
    } else {
        echo "Error: Unable to open file.";
        exit();
    }
}