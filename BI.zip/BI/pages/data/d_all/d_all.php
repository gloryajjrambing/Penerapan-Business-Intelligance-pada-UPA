<?php

// Include file koneksi database jika diperlukan
include './conf/conf.php';

// Query untuk menghapus semua data dari tabel mahasiswa
$sql = "DELETE FROM mahasiswa";

// Eksekusi query
if ($conn->query($sql) === TRUE) {
    // Redirect dengan JavaScript
    echo '<script>
             alert("All data successfully deleted!");
             window.location.href = "?q=data";
           </script>';
    exit();
} else {
    echo "Error deleting record: " . $conn->error;
}

// Tutup koneksi database
$conn->close();
