<?php
// Include file koneksi database jika diperlukan
include './conf/conf.php';

// Mendapatkan parameter filter jika ada
$prodiFilter = isset($_GET['prodi']) ? $_GET['prodi'] : null;

// Query untuk mengambil data
$stmt = $conn->prepare("SELECT PRODI, COUNT(*) as jumlah FROM mahasiswa WHERE PRODI IS NOT NULL GROUP BY PRODI");

// Jika ada filter PRODI yang dipilih
if ($prodiFilter && $prodiFilter !== 'all') {
    $stmt = $conn->prepare("SELECT PRODI, COUNT(*) as jumlah FROM mahasiswa WHERE PRODI = ? GROUP BY PRODI");
    $stmt->bind_param("s", $prodiFilter);
}

$stmt->execute();
$result = $stmt->get_result();

$data = array();

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $data[] = array("name" => $row["PRODI"], "y" => (int)$row["jumlah"]);
    }
} else {
    echo "0 results";
}

$conn->close();

// Mengembalikan data dalam format JSON
header('Content-Type: application/json');
echo json_encode($data);
