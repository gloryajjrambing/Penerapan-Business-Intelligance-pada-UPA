<?php
@$page = $_GET['q'];
if (!empty($page)) {
    switch ($page) {


        case 'beranda':
            include './pages/beranda/beranda.php';
            break;

        case 'data':
            include './pages/data/data.php';
            break;

        case 'ringkasan_data':
            include './pages/ringkasan_data/ringkasan_data.php';
            break;

        case 'import_data':
            include './pages/data/import_data/import_data.php';
            break;

        case 'd_all':
            include './pages/data/d_all/d_all.php';
            break;
    }
} else {
    include './pages/beranda/beranda.php';
}