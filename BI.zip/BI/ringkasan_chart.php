<?php
include 'conf/conf.php';

$tahunAngkatan = $_GET['tahunAngkatan'];

// Query untuk mendapatkan data berdasarkan tahun angkatan
$sql = "SELECT * FROM mahasiswa WHERE mhsAngkatan = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $tahunAngkatan);
$stmt->execute();
$result = $stmt->get_result();

$data = [];
while ($row = $result->fetch_assoc()) {
    $data[] = $row;
}

// Tutup koneksi
$stmt->close();
$conn->close();

// Mengembalikan data dalam format JSON
header('Content-Type: application/json');
echo json_encode($data);
