<?php
session_start();
include '../conf/conf.php'; // File konfigurasi untuk koneksi database

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST['username'];
    $password = $_POST['password'];
    $confirm_password = $_POST['confirm_password'];

    // Validasi input
    if (empty($username) || empty($password) || empty($confirm_password)) {
        $_SESSION['error'] = "All fields are required.";
        header("Location: ../register");
        exit();
    }

    if ($password !== $confirm_password) {
        $_SESSION['error'] = "Passwords do not match.";
        header("Location: ../register");
        exit();
    }

    // Sanitasi input
    $username = mysqli_real_escape_string($conn, $username);
    $password = mysqli_real_escape_string($conn, $password);

    // Hash password
    $hashed_password = password_hash($password, PASSWORD_DEFAULT);

    // Query untuk menambahkan user baru
    $query = "INSERT INTO users (username, password, role) VALUES ('$username', '$hashed_password', 'user')";

    if (mysqli_query($conn, $query)) {
        $_SESSION['success'] = "Registration successful. You can now log in.";
        header("Location: ../login");
        exit();
    } else {
        $_SESSION['error'] = "Error: " . $query . "<br>" . mysqli_error($conn);
        header("Location: ../register");
        exit();
    }
} else {
    header("Location: ../register");
    exit();
}