<?php
// Include file koneksi database jika diperlukan
include './conf/conf.php';

// Query untuk mengambil total mahasiswa per tahun
$sql = "SELECT mhsAngkatan, COUNT(*) as total_mahasiswa FROM mahasiswa GROUP BY mhsAngkatan";
$result = $conn->query($sql);

// Inisialisasi array untuk menampung data total mahasiswa per tahun
$data_per_tahun = array();

// Cek jika query berhasil dieksekusi
if ($result && $result->num_rows > 0) {
    // Ambil data total mahasiswa per tahun
    while ($row = $result->fetch_assoc()) {
        $tahun = "Tahun " . $row['mhsAngkatan']; // Format tahun sesuai dengan contoh ('Tahun 2022')
        $total_mahasiswa = $row['total_mahasiswa'];
        // Tambahkan data ke array
        $data_per_tahun[] = array($tahun, (int)$total_mahasiswa);
    }
}

// Tutup koneksi database
$conn->close();

// Echo data total mahasiswa per tahun sebagai data yang akan digunakan untuk membuat chart
echo json_encode($data_per_tahun);
