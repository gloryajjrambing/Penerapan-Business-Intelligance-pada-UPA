    <?php
    session_start();
    if (!isset($_SESSION['username'])) {
        header("Location: login");
        exit();
    }
    ?>


    <!DOCTYPE html>

    <html lang="en" class="light-style layout-menu-fixed" dir="ltr" data-theme="theme-default" data-assets-path="assets/" data-template="vertical-menu-template-free">

    <head>
        <meta charset="utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no, minimum-scale=1.0, maximum-scale=1.0" />

        <title>Upatik Unima</title>

        <meta name="description" content="" />

        <!-- Favicon -->
        <link rel="icon" type="image/x-icon" href="assets/img/fav.png" />

        <!-- Fonts -->
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
        <link href="https://fonts.googleapis.com/css2?family=Public+Sans:ital,wght@0,300;0,400;0,500;0,600;0,700;1,300;1,400;1,500;1,600;1,700&display=swap" rel="stylesheet" />

        <!-- Icons. Uncomment required icon fonts -->
        <link rel="stylesheet" href="assets/vendor/fonts/boxicons.css" />

        <!-- Core CSS -->
        <link rel="stylesheet" href="assets/vendor/css/core.css" class="template-customizer-core-css" />
        <link rel="stylesheet" href="assets/vendor/css/theme-default.css" class="template-customizer-theme-css" />
        <link rel="stylesheet" href="assets/css/demo.css" />

        <link rel="stylesheet" href="assets/css/baru.css">
        <link rel="stylesheet" href="assets/css/ringkasan.css">

        <!-- Vendors CSS -->
        <link rel="stylesheet" href="assets/vendor/libs/perfect-scrollbar/perfect-scrollbar.css" />

        <link rel="stylesheet" href="assets/vendor/libs/apex-charts/apex-charts.css" />

        <!-- Page CSS -->
        <link rel="stylesheet" href="assets/fontawesome/css/all.min.css">

        <!-- Helpers -->
        <script src="assets/vendor/js/helpers.js"></script>
        <script src="assets/js/config.js"></script>

        <!-- CSS DataTables -->
        <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.25/css/dataTables.bootstrap5.min.css">


        <!-- Include Chart.js Library -->
        <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

    </head>

    <body>
        <!-- Layout wrapper -->
        <div class="layout-wrapper layout-content-navbar">
            <div class="layout-container">
                <!-- Menu -->
                <aside id="layout-menu" class="layout-menu menu-vertical menu bg-menu-theme">
                    <div class="app-brand demo">
                        <a href="index" class="app-brand-link">
                            <span class="app-brand-logo demo">
                                <img src="assets/img/logobaru.png" class="img-fluid" width="200px" alt="">
                            </span>
                        </a>
                        <a href="javascript:void(0);" class="layout-menu-toggle menu-link text-large ms-auto d-block d-xl-none">
                            <i class="bx bx-chevron-left bx-sm align-middle"></i>
                        </a>
                    </div>

                    <div class="menu-inner-shadow"></div>

                    <ul class="menu-inner py-1 mt-4">
                        <!-- Dashboard -->
                        <li class="menu-item active">
                            <a href="index" class="menu-link">
                                <i class="menu-icon tf-icons bx bx-home-circle"></i>
                                <div data-i18n="Analytics">Dashboard</div>
                            </a>
                        </li>

                        <li class="menu-header small text-uppercase">
                            <span class="menu-header-text">Pages</span>
                        </li>
                        <li class="menu-item">
                            <a href="javascript:void(0);" class="menu-link menu-toggle">
                                <i class="menu-icon tf-icons bx bx-dock-top"></i>
                                <div data-i18n="Account Settings">Business Intelegent</div>
                            </a>
                            <ul class="menu-sub">
                                <li class="menu-item">
                                    <a href="?q=data" class="menu-link">
                                        <div data-i18n="Account">Data</div>
                                    </a>
                                </li>
                                <li class="menu-item">
                                    <a href="?q=ringkasan_data" class="menu-link">
                                        <div data-i18n="Account">Ringkasan</div>
                                    </a>
                                </li>
                            </ul>
                        </li>

                        <li class="menu-header small text-uppercase">
                            <span class="menu-header-text">Option</span>
                        </li>
                        <li class="menu-item">
                            <a href="javascript:void(0);" class="menu-link menu-toggle">
                                <i class="menu-icon tf-icons bx bx-dock-top"></i>
                                <div data-i18n="Account Settings">Lainnya</div>
                            </a>
                            <ul class="menu-sub">
                                <li class="menu-item">
                                    <a href="logout.php" class="menu-link">
                                        <div data-i18n="Account">Logout</div>
                                    </a>
                                </li>
                            </ul>
                        </li>

                    </ul>
                </aside>
                <!-- / Menu -->

                <!-- Layout container -->
                <div class="layout-page">
                    <!-- Navbar -->
                    <nav class="layout-navbar container-xxl navbar navbar-expand-xl navbar-detached align-items-center bg-navbar-theme" id="layout-navbar">
                        <div class="layout-menu-toggle navbar-nav align-items-xl-center me-3 me-xl-0 d-xl-none">
                            <a class="nav-item nav-link px-0 me-xl-4" href="javascript:void(0)">
                                <i class="bx bx-menu bx-sm"></i>
                            </a>
                        </div>

                        <div class="navbar-nav-right d-flex align-items-center" id="navbar-collapse">

                            <div class="navbar-nav align-items-center">
                                <div class="nav-item d-flex align-items-center">
                                    <i class="fa-solid fa-clock"></i>
                                    <div id="current-time" class="ms-2"></div>
                                </div>
                            </div>

                            <ul class="navbar-nav flex-row align-items-center ms-auto">
                                <!-- User -->
                                <li class="nav-item navbar-dropdown dropdown-user dropdown">
                                    <a class="nav-link dropdown-toggle hide-arrow" href="javascript:void(0);" data-bs-toggle="dropdown">
                                        <div class="avatar avatar-online">
                                            <img src="assets/img/avatars/1.png" alt class="w-px-40 h-auto rounded-circle" />
                                        </div>
                                    </a>
                                    <ul class="dropdown-menu dropdown-menu-end">
                                        <li>
                                            <a class="dropdown-item" href="#">
                                                <div class="d-flex">
                                                    <div class="flex-shrink-0 me-3">
                                                        <div class="avatar avatar-online">
                                                            <img src="assets/img/avatars/1.png" alt class="w-px-40 h-auto rounded-circle" />
                                                        </div>
                                                    </div>
                                                    <div class="flex-grow-1">
                                                        <span class="fw-semibold d-block"><?php echo $_SESSION['username']; ?></span>
                                                        <small class="text-muted"><?php echo ucfirst($_SESSION['role']); ?></small>
                                                    </div>
                                                </div>
                                            </a>
                                        </li>
                                        <li>
                                            <div class="dropdown-divider"></div>
                                        </li>
                                        <li>
                                            <a class="dropdown-item" href="#">
                                                <i class="bx bx-user me-2"></i>
                                                <span class="align-middle">My Profile</span>
                                            </a>
                                        </li>
                                        <li>
                                            <a class="dropdown-item" href="#">
                                                <i class="bx bx-cog me-2"></i>
                                                <span class="align-middle">Settings</span>
                                            </a>
                                        </li>

                                        <li>
                                            <div class="dropdown-divider"></div>
                                        </li>
                                        <li>
                                            <a class="dropdown-item" href="logout">
                                                <i class="bx bx-power-off me-2"></i>
                                                <span class="align-middle">Log Out</span>

                                            </a>
                                        </li>
                                    </ul>
                                </li>
                                <!--/ User -->
                            </ul>
                        </div>
                    </nav>

                    <!-- / Navbar -->

                    <!-- Content wrapper -->
                    <div class="content-wrapper">
                        <!-- Content -->
                        <?php include 'link.php'; ?>
                        <!-- / Content -->

                        <!-- Footer -->
                        <footer class="content-footer footer bg-footer-theme">
                            <div class="container-xxl d-flex flex-wrap justify-content-between py-2 flex-md-row flex-column">
                                <div class="mb-2 mb-md-0">
                                    ©
                                    <script>
                                        document.write(new Date().getFullYear());
                                    </script>
                                    , made with ❤️ by
                                    <a href="" target="_blank" class="footer-link fw-bolder">Glory</a>
                                </div>
                                <div>
                                    <a href="index" class="footer-link me-4">Made in Tondano, 2024</a>

                                </div>
                            </div>
                        </footer>
                        <!-- / Footer -->

                        <div class="content-backdrop fade"></div>
                    </div>
                    <!-- Content wrapper -->
                </div>
                <!-- / Layout page -->
            </div>

            <!-- Overlay -->
            <div class="layout-overlay layout-menu-toggle"></div>
        </div>
        <!-- / Layout wrapper -->

        <!-- Core JS -->

        <!-- Memuat jQuery -->
        <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

        <!-- Memuat pustaka DataTables -->
        <script type="text/javascript" src="https://cdn.datatables.net/1.10.25/js/jquery.dataTables.min.js"></script>
        <script type="text/javascript" src="https://cdn.datatables.net/1.10.25/js/dataTables.bootstrap5.min.js">
        </script>

        <!-- Skrip inisialisasi DataTables -->
        <script type="text/javascript">
            $(document).ready(function() {
                $('#dataTable').DataTable();
            });
        </script>

        <!-- Skrip inisialisasi DataTables -->
        <script type="text/javascript">
            $(document).ready(function() {
                $('#pertama').DataTable();
            });
        </script>

        <script type="text/javascript">
            $(document).ready(function() {
                $('#kedua').DataTable();
            });
        </script>

        <script type="text/javascript">
            $(document).ready(function() {
                $('#ketiga').DataTable();
            });
        </script>





        <!-- <script src="assets/vendor/libs/jquery/jquery.js"></script> -->
        <script src="assets/vendor/libs/popper/popper.js"></script>
        <script src="assets/vendor/js/bootstrap.js"></script>
        <script src="assets/vendor/libs/perfect-scrollbar/perfect-scrollbar.js"></script>

        <script src="assets/vendor/js/menu.js"></script>
        <!-- endbuild -->

        <!-- Vendors JS -->
        <script src="assets/vendor/libs/apex-charts/apexcharts.js"></script>

        <!-- Main JS -->
        <script src="assets/js/main.js"></script>

        <!-- Page JS -->
        <script src="assets/js/dashboards-analytics.js"></script>

        <!-- Place this tag in your head or just before your close body tag. -->
        <script async defer src="https://buttons.github.io/buttons.js"></script>



        <script>
            function updateTime() {
                const now = new Date();
                const formattedTime = now.toLocaleTimeString();
                document.getElementById('current-time').textContent = formattedTime;
            }

            setInterval(updateTime, 1000); // Update time every second
            updateTime(); // Initial call to set the time immediately
        </script>


        <script>
            $(document).ready(function() {
                // Event handler untuk setiap kali nilai dropdown berubah
                $('#tahunAngkatanFilter, #fakultasFilter, #prodiFilter').change(function() {
                    // Mendapatkan nilai yang dipilih dari setiap dropdown
                    var tahunAngkatan = $('#tahunAngkatanFilter').val();
                    var fakultas = $('#fakultasFilter').val();
                    var prodi = $('#prodiFilter').val();

                    // Mengirimkan nilai filter ke server dengan AJAX
                    $.ajax({
                        type: 'POST',
                        url: 'filter.php', // Ganti dengan URL yang benar
                        data: {
                            tahunAngkatan: tahunAngkatan,
                            fakultas: fakultas,
                            prodi: prodi
                        },
                        success: function(response) {
                            // Memperbarui isi tabel dengan data yang difilter
                            $('#dataTable tbody').html(response);
                        }
                    });
                });
            });
        </script>



        <script src="https://code.highcharts.com/highcharts.js"></script>
        <script src="https://code.highcharts.com/modules/exporting.js"></script>
        <script src="https://code.highcharts.com/modules/accessibility.js"></script>
        <!-- Script untuk membuat grafik -->
        <script>
            document.addEventListener('DOMContentLoaded', function() {
                // Ambil data total mahasiswa dari PHP menggunakan AJAX
                var xhttp = new XMLHttpRequest();
                xhttp.onreadystatechange = function() {
                    if (this.readyState == 4 && this.status == 200) {
                        // Parse data total mahasiswa dari response
                        var data_per_tahun = JSON.parse(this.responseText);

                        // Buat data untuk chart
                        var data = [];
                        for (var i = 0; i < data_per_tahun.length; i++) {
                            data.push({
                                name: data_per_tahun[i][0],
                                y: data_per_tahun[i][1]
                            });
                        }

                        // Tentukan opsi chart
                        var options = {
                            chart: {
                                type: 'bar'
                            },
                            title: {
                                text: 'Total Mahasiswa per Tahun'
                            },
                            xAxis: {
                                type: 'category',
                                title: {
                                    text: 'Tahun'
                                }
                            },
                            yAxis: {
                                title: {
                                    text: 'Total Mahasiswa'
                                }
                            },
                            series: [{
                                name: 'Total Mahasiswa',
                                data: data
                            }]
                        };

                        // Buat instance chart dan render di div dengan id 'chart_div'
                        Highcharts.chart('chart_div', options);
                    }
                };
                xhttp.open("GET", "chart.php", true);
                xhttp.send();
            });
        </script>


        <script>
            document.addEventListener('DOMContentLoaded', function() {
                var colors = ['#FF5733', '#33FF57', '#5733FF', '#FF33E9', '#33E9FF']; // Definisikan array warna

                function updateChart(data) {
                    Highcharts.chart('chart_div_pie', {
                        chart: {
                            type: 'pie'
                        },
                        title: {
                            text: 'Total Mahasiswa Tiap Jurusan'
                        },
                        series: [{
                            name: 'Jumlah Mahasiswa',
                            colorByPoint: true,
                            data: data.map((item, index) => {
                                // Setiap PRODI akan memiliki warna yang berbeda
                                return {
                                    name: item.name,
                                    y: item.y,
                                    color: colors[index % colors
                                        .length
                                    ] // Menetapkan warna berdasarkan indeks data
                                };
                            })
                        }]
                    });
                }

                function fetchData(prodi) {
                    var xhttp = new XMLHttpRequest();
                    xhttp.onreadystatechange = function() {
                        if (this.readyState == 4 && this.status == 200) {
                            var data = JSON.parse(this.responseText);
                            updateChart(data);
                        }
                    };
                    var url = "chartpie.php";
                    if (prodi && prodi !== 'all') {
                        url += "?prodi=" + prodi;
                    }
                    xhttp.open("GET", url, true);
                    xhttp.send();
                }

                // Ambil daftar PRODI untuk filter
                fetch('chartpie.php')
                    .then(response => response.json())
                    .then(data => {
                        var prodiList = new Set(data.map(item => item.name));
                        var filterSelect = document.getElementById('prodiFilter');
                        prodiList.forEach(prodi => {
                            var option = document.createElement('option');
                            option.value = prodi;
                            option.textContent = prodi;
                            filterSelect.appendChild(option);
                        });
                        // Set default value untuk filter
                        filterSelect.value = 'all';
                    });

                // Inisialisasi grafik dengan semua data
                fetchData();

                // Perbarui grafik saat filter berubah
                document.getElementById('prodiFilter').addEventListener('change', function() {
                    fetchData(this.value);
                });
            });
        </script>




    </body>

    </html>